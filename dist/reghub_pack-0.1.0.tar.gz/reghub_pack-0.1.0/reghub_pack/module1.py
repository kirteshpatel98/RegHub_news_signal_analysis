class mod1:
    def __init__(self):
        print("hi there")
    
    def mod_nam(self,name):
        self.name=name
        print("hi ",self.name)